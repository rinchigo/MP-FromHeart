import 'package:flutter/material.dart';

class AddMenuPage extends StatefulWidget {
  @override
  _AddMenuPageState createState() => _AddMenuPageState();
}

class _AddMenuPageState extends State<AddMenuPage> {
  final _formKey = GlobalKey<FormState>();
  String _itemName = '';
  String _itemDescription = '';
  double _itemPrice = 0.0;
  String _itemImageUrl = '';

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      // You can handle the data, add it to your menu or database
      print('Item Name: $_itemName');
      print('Item Description: $_itemDescription');
      print('Item Price: $_itemPrice');
      print('Item Image URL: $_itemImageUrl');

      Navigator.pop(context); // Return to the main menu after adding
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: Text('Add New Menu Item'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              // Item Name
              TextFormField(
                decoration: InputDecoration(labelText: 'Item Name'),
                onSaved: (value) {
                  _itemName = value ?? '';
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an item name';
                  }
                  return null;
                },
              ),
              // Item Description
              TextFormField(
                decoration: InputDecoration(labelText: 'Item Description'),
                onSaved: (value) {
                  _itemDescription = value ?? '';
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a description';
                  }
                  return null;
                },
              ),
              // Item Price
              TextFormField(
                decoration: InputDecoration(labelText: 'Item Price'),
                keyboardType: TextInputType.number,
                onSaved: (value) {
                  _itemPrice = double.tryParse(value ?? '') ?? 0.0;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a price';
                  } else if (double.tryParse(value) == null) {
                    return 'Please enter a valid price';
                  }
                  return null;
                },
              ),
              // Item Image URL
              TextFormField(
                decoration: InputDecoration(labelText: 'Item Image URL'),
                onSaved: (value) {
                  _itemImageUrl = value ?? '';
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an image URL';
                  }
                  return null;
                },
              ),
              // Submit Button
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: ElevatedButton(
                  onPressed: _submitForm,
                  child: Text('Add Item'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                   disabledBackgroundColor: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
