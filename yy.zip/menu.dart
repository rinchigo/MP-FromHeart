import 'package:flutter/material.dart';

class MenuPage extends StatelessWidget {
  final Function(String) onAddToCart;

  MenuPage({required this.onAddToCart});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 10, // Example number of items
      itemBuilder: (context, index) {
        return ListTile(
          title: Text('Item $index'),
          trailing: IconButton(
            icon: Icon(Icons.add_shopping_cart),
            onPressed: () {
              // Add item to the cart
              onAddToCart('Item $index');
            },
          ),
        );
      },
    );
  }
}
