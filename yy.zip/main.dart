import 'package:flutter/material.dart';
import 'addmenu.dart'; // Assuming AddMenuPage exists
import 'menu.dart'; // Import MenuPage
import 'cart.dart'; // Import CartPage

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<String> cartItems = [];

  void addToCart(String item) {
    setState(() {
      cartItems.add(item);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text('Menu Page', style: TextStyle(color: Colors.green)),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart, color: Colors.green),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CartPage(initialCartItems: cartItems),
                ),
              );
            },
          ),
        ],
      ),
      body: MenuPage(onAddToCart: addToCart),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home, color: Colors.green),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today, color: Colors.green),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add, color: Colors.green),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.edit, color: Colors.green),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings, color: Colors.green),
            label: '',
          ),
        ],
        onTap: (index) {
          // Handle your bottom navigation functionality here.
        },
      ),
    );
  }
}

// MenuPage Example
class MenuPage extends StatelessWidget {
  final Function(String) onAddToCart;

  MenuPage({required this.onAddToCart});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 10, // Example number of items
      itemBuilder: (context, index) {
        return ListTile(
          title: Text('Item $index'),
          trailing: IconButton(
            icon: Icon(Icons.add_shopping_cart),
            onPressed: () {
              // Add item to the cart
              onAddToCart('Item $index');
            },
          ),
        );
      },
    );
  }
}

// CartPage Example
class CartPage extends StatelessWidget {
  final List<String> initialCartItems;

  CartPage({required this.initialCartItems});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text('Cart', style: TextStyle(color: Colors.green)),
      ),
      body: initialCartItems.isEmpty
          ? Center(child: Text('Your cart is empty.'))
          : ListView.builder(
              itemCount: initialCartItems.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(initialCartItems[index]),
                );
              },
            ),
    );
  }
}
