import 'package:flutter/material.dart';

class CartPage extends StatelessWidget {
  final List<String> initialCartItems;

  CartPage({required this.initialCartItems});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text('Cart', style: TextStyle(color: Colors.green)),
      ),
      body: initialCartItems.isEmpty
          ? Center(child: Text('Your cart is empty.'))
          : ListView.builder(
              itemCount: initialCartItems.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(initialCartItems[index]),
                );
              },
            ),
    );
  }
}
